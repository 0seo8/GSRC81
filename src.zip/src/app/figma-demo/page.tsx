import { FigmaShowcase } from "@/components/examples/figma-showcase"

export default function FigmaDemoPage() {
  return (
    <div className="min-h-screen">
      <FigmaShowcase />
    </div>
  )
}
