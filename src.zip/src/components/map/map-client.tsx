"use client";

import { useTransition, useState } from "react";
import { useRouter } from "next/navigation";

import { MapboxMap } from "./mapbox-map";
import { CourseMarker } from "./course-marker";
import { CourseDrawer } from "./course-drawer";
import { MapTokenError } from "./map-token-error";
import { MapEmptyState } from "./map-empty-state";
import { useMapState } from "@/hooks/use-map-state";
import { useMapBounds } from "@/hooks/use-map-bounds";
import { type CourseWithComments } from "@/lib/courses-data";

interface MapClientProps {
  courses: CourseWithComments[];
}

export function MapClient({ courses }: MapClientProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [currentCategory, setCurrentCategory] = useState('jingwan');
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);

  // 현재 카테고리에 맞는 코스만 필터링
  const filteredCourses = courses.filter(course => 
    (course.category_key || 'jingwan') === currentCategory
  );

  const {
    map,
    selectedCourse,
    selectedCourses,
    optimisticCourses,
    handleMapLoad,
    handleCourseClick,
    handleClusterClick,
    handleCloseDrawer,
  } = useMapState(filteredCourses);

  useMapBounds(map, optimisticCourses);

  const mapboxToken = process.env.NEXT_PUBLIC_MAPBOX_ACCESS_TOKEN || "";

  const handleCourseCardClick = (courseId: string) => {
    // React 19의 startTransition을 사용하여 네비게이션을 낮은 우선순위로 처리
    startTransition(() => {
      router.push(`/courses/${courseId}`);
      handleCloseDrawer();
    });
  };

  // 카테고리 전환 함수
  const categories = ['jingwan', 'track', 'trail', 'road'];
  const categoryNames = {
    jingwan: '진관동러닝',
    track: '트랙러닝', 
    trail: '트레일러닝',
    road: '로드러닝'
  };
  
  const handleCategorySwipe = (direction: 'left' | 'right') => {
    const currentIndex = categories.indexOf(currentCategory);
    let newIndex;
    
    if (direction === 'left' && currentIndex > 0) {
      newIndex = currentIndex - 1;
    } else if (direction === 'right' && currentIndex < categories.length - 1) {
      newIndex = currentIndex + 1;
    } else {
      return; // 범위를 벗어나면 무시
    }
    
    setCurrentCategory(categories[newIndex]);
    handleCloseDrawer(); // 드로어 닫기
  };

  // 터치 이벤트 핸들러들
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > 50;
    const isRightSwipe = distance < -50;

    if (isLeftSwipe) {
      handleCategorySwipe('right'); // 왼쪽으로 스와이프하면 다음 카테고리로
    }
    if (isRightSwipe) {
      handleCategorySwipe('left'); // 오른쪽으로 스와이프하면 이전 카테고리로
    }
  };

  // Mapbox 토큰이 없는 경우
  if (!mapboxToken) {
    return <MapTokenError />;
  }

  // 코스가 없는 경우
  if (optimisticCourses.length === 0) {
    return (
      <MapEmptyState mapboxToken={mapboxToken} onMapLoad={handleMapLoad} />
    );
  }

  return (
    <div className="h-screen bg-gray-100 flex flex-col overflow-hidden">
      <div 
        className="flex-1 relative overflow-hidden"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* 카테고리 헤더 */}
        <div className="absolute top-4 left-4 right-4 z-30">
          <div className="bg-white rounded-lg shadow-md p-3">
            <div className="flex items-center justify-between">
              <button
                onClick={() => handleCategorySwipe('left')}
                disabled={categories.indexOf(currentCategory) === 0}
                className="p-2 disabled:opacity-30"
              >
                ←
              </button>
              <div className="text-center">
                <h3 className="text-lg font-bold">{categoryNames[currentCategory as keyof typeof categoryNames]}</h3>
                <div className="flex space-x-1 justify-center mt-1">
                  {categories.map((category) => (
                    <div
                      key={category}
                      className={`w-2 h-2 rounded-full ${
                        category === currentCategory ? 'bg-gray-600' : 'bg-gray-300'
                      }`}
                    />
                  ))}
                </div>
              </div>
              <button
                onClick={() => handleCategorySwipe('right')}
                disabled={categories.indexOf(currentCategory) === categories.length - 1}
                className="p-2 disabled:opacity-30"
              >
                →
              </button>
            </div>
          </div>
        </div>

        {/* 지도 */}
        <MapboxMap
          accessToken={mapboxToken}
          center={[127.5, 36.5]}
          zoom={10.5} // 줌 범위 10-12.85 내에서 시작
          onMapLoad={handleMapLoad}
          className="w-full h-full"
          style="mapbox://styles/mapbox/light-v11"
        />

        {/* 코스 마커 */}
        {map && (
          <CourseMarker
            map={map}
            courses={optimisticCourses}
            onCourseClick={handleCourseClick}
            onClusterClick={handleClusterClick}
          />
        )}

        {/* 로딩 인디케이터 (transition 중일 때) */}
        {isPending && (
          <div className="absolute top-4 left-4 bg-white rounded-lg shadow-md p-2 z-10">
            <div className="flex items-center space-x-2">
              <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-gray-600"></div>
              <span className="text-xs text-gray-600">업데이트 중...</span>
            </div>
          </div>
        )}

        {/* 코스 카드 드로어 */}
        <CourseDrawer
          selectedCourses={selectedCourses}
          selectedCourse={selectedCourse}
          onClose={handleCloseDrawer}
          onCourseClick={handleCourseCardClick}
        />
      </div>
    </div>
  );
}
