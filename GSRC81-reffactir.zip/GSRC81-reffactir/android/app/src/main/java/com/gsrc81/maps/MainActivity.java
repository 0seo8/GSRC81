package com.gsrc81.maps;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
