"use client";

import { motion, AnimatePresence } from "framer-motion";
import { CourseCardStack } from "./course-card-stack";
import { type CourseWithComments } from "@/lib/courses-data";
import { useState } from "react";

interface CourseDrawerProps {
  selectedCourses: CourseWithComments[];
  selectedCourse: CourseWithComments | null;
  onClose: () => void;
  onCourseClick: (courseId: string) => void;
}

export function CourseDrawer({
  selectedCourses,
  selectedCourse,
  onClose,
  onCourseClick,
}: CourseDrawerProps) {
  const [isDragging, setIsDragging] = useState(false);
  const isOpen = selectedCourses.length > 0 || selectedCourse !== null;
  const courses = selectedCourses.length > 0 
    ? selectedCourses 
    : selectedCourse 
    ? [selectedCourse] 
    : [];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* 백드롭 */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-white z-20"
            onClick={onClose}
          />
          
          {/* 드로어 */}
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{
              type: "spring",
              damping: 25,
              stiffness: 300,
              duration: 0.3,
            }}
            drag="y"
            dragConstraints={{ top: 0 }}
            dragElastic={0.2}
            onDragStart={() => setIsDragging(true)}
            onDragEnd={(_, info) => {
              setIsDragging(false);
              // 드래그 속도나 거리가 충분하면 드로어를 닫음
              if (info.velocity.y > 500 || info.offset.y > 100) {
                onClose();
              }
            }}
            className="absolute inset-0 bg-white z-30 flex flex-col drawer-safe-bottom cursor-grab active:cursor-grabbing"
            onClick={(e) => {
              // 드래그 중이 아닐 때만 클릭으로 닫기
              if (!isDragging) {
                onClose();
              }
            }}
          >
            <CourseCardStack
              courses={courses}
              onClose={onClose}
              onCourseClick={onCourseClick}
            />
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}